var config = {
    map: {
        '*': {
            ajax: 'Khoa_District/js/customer',
        }
    }
};