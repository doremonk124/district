<?php
namespace Khoa\Currency\Controller\Index;

class Index extends \Magento\Framework\App\Action\Action
{
    public function execute()
    {
        $layout = $this->_view->getLayout();
        $block = $layout->createBlock('Magento\Framework\View\Element\Text');
        $block->setText('Hello world from Nam currency !');
//        $this->getResponse()->appendBody($block->toHtml());
//
//        $uri = 'https://free.currencyconverterapi.com/api/v6/convert?q=USD_VND&compact=ultra&apiKey=f9251b30c23b8f97cd0c';
//        $httpClient = new \Zend\Http\Client();
//
//        $httpClient->setUri($uri);
//        $httpClient->setOptions(array(
//            'timeout' => 30
//        ));
//        try {
//            $response = \Zend\Json\Decoder::decode($httpClient->send()->getBody());
//            if (isset($response->USD_VND)) {
//                $block->setText(' 1 USD = ' . $response->USD_VND . ' VND');
//            }
//        } catch (\Exception $e) {
//            $block->setText($e->getMessage());
//        }
        $this->getResponse()->appendBody($block->toHtml());
    }
}